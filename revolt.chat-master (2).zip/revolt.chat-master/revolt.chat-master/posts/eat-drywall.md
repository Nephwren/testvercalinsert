---
title: "How to eat drywall"
description: Instructional guide on how to eat drywall
author: Revolt
coverImage: /content/blog/eat-drywall/drywall-cory-woodward-JUqmfHPJNE8-unsplash.jpg
date: "2022-05-08T12:00:00.000Z"
---

> Image Credit: [Cory Woodward on Unsplash](https://unsplash.com/photos/JUqmfHPJNE8)

**Disclaimer: Consult a doctor before consuming drywall.**

Instructions:

1. Acquire drywall
2. Consume drywall

---

# Additional Information

> Instructional gif on how to consume drywall

![](https://c.tenor.com/lCSsC5hSpAYAAAAC/garfield-drywall.gif)

> Example of anti-drywall eating propaganda

![](https://c.tenor.com/UrZGHw036AoAAAAC/rainbow-six-siege-siege.gif)

> Live footage I recorded earlier

![](https://c.tenor.com/noKLy1lamBMAAAAd/shrek-get-away.gif)

---

Thank you for coming to my presentation.
