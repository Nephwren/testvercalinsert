import URLs from '../urls';
import redirect from 'nextjs-redirect';
export default redirect(URLs.ProjectTracker);
